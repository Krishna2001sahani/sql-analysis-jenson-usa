-- Q6.Find the total number of orders placed by each customer per store.
SELECT 
    o.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    o.store_id,
    s.store_name,
    COUNT(o.order_id) AS total_orders
FROM 
    orders o
JOIN 
    customers c ON o.customer_id = c.customer_id
JOIN 
    stores s ON o.store_id = s.store_id
GROUP BY 
    o.customer_id, c.first_name, c.last_name, o.store_id, s.store_name
ORDER BY 
    o.customer_id, o.store_id;
