
-- Q7.Find the names of staff members who have not made any sales.
SELECT 
    s.staff_id,
    CONCAT(s.first_name, ' ', s.last_name) AS staff_name,
    s.email,
    s.phone
FROM 
    staffs s
LEFT JOIN 
    orders o ON s.staff_id = o.staff_id
WHERE 
    o.order_id IS NULL;

