-- Q5.Find the highest-priced product for each category name.

SELECT 
    c.category_id,
    c.category_name,
    p.product_id,
    p.product_name,
    p.list_price
FROM 
    products p
JOIN 
    categories c ON p.category_id = c.category_id
WHERE 
    p.list_price = (
        SELECT 
            MAX(p2.list_price)
        FROM 
            products p2
        WHERE 
            p2.category_id = p.category_id
    );
