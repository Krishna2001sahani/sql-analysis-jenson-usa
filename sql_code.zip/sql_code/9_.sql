
-- Q9.Find the median value of the price list.
WITH RankedPrices AS (
    SELECT 
        list_price,
        ROW_NUMBER() OVER (ORDER BY list_price) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM 
        products
)
SELECT 
    AVG(list_price) AS median_price
FROM 
    RankedPrices
WHERE 
    row_num IN (FLOOR((total_count + 1) / 2), CEIL((total_count + 1) / 2));
 