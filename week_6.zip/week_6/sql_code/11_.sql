

-- Q11.List the names of staff members who have made more sales than the average number of sales by all staff members.
WITH StaffSales AS (
    SELECT 
        s.staff_id,
        CONCAT(s.first_name, ' ', s.last_name) AS staff_name,
        COUNT(o.order_id) AS total_sales
    FROM 
        staffs s
    JOIN 
        orders o ON s.staff_id = o.staff_id
    GROUP BY 
        s.staff_id, s.first_name, s.last_name
),
AverageSales AS (
    SELECT 
        AVG(total_sales) AS avg_sales
    FROM 
        StaffSales
)
SELECT 
    ss.staff_id,
    ss.staff_name,
    ss.total_sales
FROM 
    StaffSales ss
CROSS JOIN 
    AverageSales a
WHERE 
    ss.total_sales > a.avg_sales;
