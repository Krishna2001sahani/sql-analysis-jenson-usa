
-- Q1.  Find the total number of products sold by each store along with the store name.  write sql querry 
SELECT 
    s.store_name, 
    SUM(oi.quantity) AS total_products_sold
FROM 
    stores s
JOIN 
    orders o ON s.store_id = o.store_id
JOIN 
    order_items oi ON o.order_id = oi.order_id
GROUP BY 
    s.store_name
ORDER BY 
    total_products_sold DESC; -- Optional: Add ordering for better insight
