
-- Q3.Find the product with the highest total sales (quantity * price) for each category.
WITH ProductSales AS (
    SELECT 
        c.category_id,
        c.category_name,
        p.product_id,
        SUM(oi.quantity * oi.list_price) AS total_sales
    FROM 
        order_items oi
    JOIN 
        products p ON oi.product_id = p.product_id
    JOIN 
        categories c ON p.category_id = c.category_id
    GROUP BY 
        c.category_id, c.category_name, p.product_id
),
RankedSales AS (
    SELECT 
        category_id,
        category_name,
        product_id,
        total_sales,
        ROW_NUMBER() OVER (
            PARTITION BY category_id 
            ORDER BY total_sales DESC
        ) AS sales_rank
    FROM 
        ProductSales
)
SELECT 
    category_id,
    category_name,
    product_id,
    total_sales
FROM 
    RankedSales
WHERE 
    sales_rank = 1;
