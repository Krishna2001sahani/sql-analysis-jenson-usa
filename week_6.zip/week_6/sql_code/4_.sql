
-- Q4.Find the customer who spent the most money on orders.
WITH CustomerSpending AS (
    SELECT 
        o.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        SUM((oi.quantity * oi.list_price) - (oi.quantity * oi.list_price * oi.discount / 100)) AS total_spent
    FROM 
        orders o
    JOIN 
        order_items oi ON o.order_id = oi.order_id
    JOIN 
        customers c ON o.customer_id = c.customer_id
    GROUP BY 
        o.customer_id, c.first_name, c.last_name
)
SELECT 
    customer_id,
    customer_name,
    total_spent
FROM 
    CustomerSpending
ORDER BY 
    total_spent DESC
LIMIT 5;
